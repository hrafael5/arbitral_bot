let pair = '';
let originalDirection = ''; 
let entryBuyExName = 'mexc'; 
let entrySellExName = 'mexc'; 
let entryBuyInstrumentIsSpot = true;
let entrySellInstrumentIsSpot = false;

const popupPairDisplayEl = document.getElementById('popupPairDisplay');
const popupLeg1ExchangeEl = document.getElementById('popupLeg1Exchange');
const popupLeg1InstrumentEl = document.getElementById('popupLeg1Instrument');
const popupLeg1PriceEl = document.getElementById('popupLeg1Price');
const popupProfitEEl = document.getElementById('popupProfitE'); 
const popupProfitSEl = document.getElementById('popupProfitS'); 
const popupLeg2ExchangeEl = document.getElementById('popupLeg2Exchange');
const popupLeg2InstrumentEl = document.getElementById('popupLeg2Instrument');
const popupLeg2PriceEl = document.getElementById('popupLeg2Price');

const openChartButtonEl = document.getElementById('openChartButton');

function formatPriceForDisplay(price, decimals = 7) { 
    if (typeof price !== 'number' || isNaN(price)) return '-'; 
    if (price < 0.00001 && price !== 0 && price > -0.00001) return price.toPrecision(3);
    return price.toFixed(decimals); 
}

function getRelevantDecimals(price) {
    if (price === null || price === undefined || isNaN(price)) return 7;
    const absPrice = Math.abs(price);
    if (absPrice >= 100) return 2;
    if (absPrice >= 1) return 4;
    if (absPrice >= 0.01) return 5;
    if (absPrice >= 0.0001) return 6;
    return 7;
}

function formatProfitPercentageForDisplay(profitPercentage, element) {
    if (!element) return;
    let textToShow = "Dados...";
    let baseClassName = element.id === 'popupProfitS' ? 'value-s profit-value' : 'value profit-value';
    let finalClassName = `${baseClassName} zero`;

    if (typeof profitPercentage === 'number' && !isNaN(profitPercentage)) {
        textToShow = (profitPercentage >= 0 ? '+' : '') + profitPercentage.toFixed(2) + '%';
        if (profitPercentage > 0.009) finalClassName = `${baseClassName} positive`;
        else if (profitPercentage < -0.009) finalClassName = `${baseClassName} negative`;
    }
    element.textContent = textToShow;
    element.className = finalClassName;
}

function calculateLucroS_PopUp(mainState) {
    if (!mainState || !mainState.allPairsData || !mainState.config || !mainState.config.exchanges) {
        return NaN;
    }
    const configForS_BuyLeg = mainState.config.exchanges[entrySellExName.toLowerCase()]; 
    const configForS_SellLeg = mainState.config.exchanges[entryBuyExName.toLowerCase()]; 

    if (!configForS_BuyLeg || !configForS_SellLeg) {
        console.warn(`[CalcPopUpS] Config de taxas não encontrada para ${entrySellExName} ou ${entryBuyExName} (para Lucro S)`);
        return NaN;
    }

    const marketDataForS_BuyLeg = mainState.allPairsData.find(p => p.pair === pair && p.exchange.toLowerCase() === entrySellExName.toLowerCase());
    const marketDataForS_SellLeg = mainState.allPairsData.find(p => p.pair === pair && p.exchange.toLowerCase() === entryBuyExName.toLowerCase());

    if (!marketDataForS_BuyLeg || !marketDataForS_SellLeg) return NaN;

    let price_S_Buy, fee_S_Buy;
    if (entrySellInstrumentIsSpot) {
        price_S_Buy = marketDataForS_BuyLeg.spotPrice; 
        fee_S_Buy = parseFloat(configForS_BuyLeg.spotMakerFee);
    } else {
        price_S_Buy = marketDataForS_BuyLeg.futuresPrice; 
        fee_S_Buy = parseFloat(configForS_BuyLeg.futuresMakerFee);
    }

    let price_S_Sell, fee_S_Sell;
    if (entryBuyInstrumentIsSpot) {
        price_S_Sell = marketDataForS_SellLeg.spotBid; 
        fee_S_Sell = parseFloat(configForS_SellLeg.spotMakerFee);
    } else {
        price_S_Sell = marketDataForS_SellLeg.futuresBid; 
        fee_S_Sell = parseFloat(configForS_SellLeg.futuresMakerFee);
    }
    
    if (isNaN(fee_S_Buy)) fee_S_Buy = 0;
    if (isNaN(fee_S_Sell)) fee_S_Sell = 0;

    if (typeof price_S_Buy === 'number' && typeof price_S_Sell === 'number' && price_S_Buy > 0 && !isNaN(price_S_Buy) && !isNaN(price_S_Sell)) {
        const grossSpreadS = (price_S_Sell / price_S_Buy) - 1;
        const netSpreadS = grossSpreadS - fee_S_Buy - fee_S_Sell; 
        return netSpreadS * 100; 
    }
    return NaN;
}

function updatePopupDisplay() {
    if (window.opener && window.opener.closed) {
        formatProfitPercentageForDisplay(NaN, popupProfitEEl);
        formatProfitPercentageForDisplay(NaN, popupProfitSEl);
        if (window.profitUpdateInterval) clearInterval(window.profitUpdateInterval);
        return;
    }
    
    const mainState = window.opener && window.opener.frontendState; 
    if (!mainState || !mainState.allPairsData || !mainState.config || !mainState.config.exchanges) {
        formatProfitPercentageForDisplay(NaN, popupProfitEEl);
        formatProfitPercentageForDisplay(NaN, popupProfitSEl);
        return;
    }

    try {
        const configEntryBuyEx = mainState.config.exchanges[entryBuyExName.toLowerCase()];
        const configEntrySellEx = mainState.config.exchanges[entrySellExName.toLowerCase()];

        if (!configEntryBuyEx || !configEntrySellEx) {
            console.warn(`[CalcPopUpNew] Config de taxas não encontrada para ${entryBuyExName} ou ${entrySellExName}`);
            formatProfitPercentageForDisplay(NaN, popupProfitEEl);
            formatProfitPercentageForDisplay(NaN, popupProfitSEl);
            return;
        }
        
        const feeForEntryBuyOrder = entryBuyInstrumentIsSpot ? parseFloat(configEntryBuyEx.spotMakerFee) : parseFloat(configEntryBuyEx.futuresMakerFee);
        const feeForEntrySellOrder = entrySellInstrumentIsSpot ? parseFloat(configEntrySellEx.spotMakerFee) : parseFloat(configEntrySellEx.futuresMakerFee);
        
        const marketDataForEntryBuyLeg = mainState.allPairsData.find(p => p.pair === pair && p.exchange.toLowerCase() === entryBuyExName.toLowerCase());
        const marketDataForEntrySellLeg = mainState.allPairsData.find(p => p.pair === pair && p.exchange.toLowerCase() === entrySellExName.toLowerCase());

        if (marketDataForEntryBuyLeg && marketDataForEntrySellLeg) {
            const priceToBuyEntry = entryBuyInstrumentIsSpot ? marketDataForEntryBuyLeg.spotPrice : marketDataForEntryBuyLeg.futuresPrice; 
            const priceToSellEntry = entrySellInstrumentIsSpot ? marketDataForEntrySellLeg.spotBid : marketDataForEntrySellLeg.futuresBid; 
            
            let netSpreadMakerEntry = NaN;
            if (typeof priceToBuyEntry === 'number' && typeof priceToSellEntry === 'number' && priceToBuyEntry > 0 && !isNaN(priceToBuyEntry) && !isNaN(priceToSellEntry)) {
                const grossSpreadMaker = (priceToSellEntry / priceToBuyEntry) - 1;
                netSpreadMakerEntry = grossSpreadMaker - feeForEntryBuyOrder - feeForEntrySellOrder;
            }
            formatProfitPercentageForDisplay(netSpreadMakerEntry * 100, popupProfitEEl);
            
            const netSpreadMakerS_percentage = calculateLucroS_PopUp(mainState);
            formatProfitPercentageForDisplay(netSpreadMakerS_percentage, popupProfitSEl);

            if (popupPairDisplayEl) popupPairDisplayEl.textContent = pair.split('/')[0];
            if (popupLeg1ExchangeEl) popupLeg1ExchangeEl.textContent = entryBuyExName.length > 4 ? entryBuyExName.substring(0,4).toUpperCase() : entryBuyExName.toUpperCase();
            if (popupLeg1InstrumentEl) popupLeg1InstrumentEl.textContent = entryBuyInstrumentIsSpot ? 'S' : 'F';
            if (popupLeg1PriceEl) popupLeg1PriceEl.textContent = formatPriceForDisplay(priceToBuyEntry, getRelevantDecimals(priceToBuyEntry));
            if (popupLeg2ExchangeEl) popupLeg2ExchangeEl.textContent = entrySellExName.length > 4 ? entrySellExName.substring(0,4).toUpperCase() : entrySellExName.toUpperCase();
            if (popupLeg2InstrumentEl) popupLeg2InstrumentEl.textContent = entrySellInstrumentIsSpot ? 'S' : 'F';
            if (popupLeg2PriceEl) popupLeg2PriceEl.textContent = formatPriceForDisplay(priceToSellEntry, getRelevantDecimals(priceToSellEntry));
            
        } else {
            formatProfitPercentageForDisplay(NaN, popupProfitEEl);
            formatProfitPercentageForDisplay(NaN, popupProfitSEl);
            if (popupLeg1PriceEl) popupLeg1PriceEl.textContent = "Dados?";
            if (popupLeg2PriceEl) popupLeg2PriceEl.textContent = "Dados?";
        }
    } catch (e) {
        console.error("[CalcPopUpNew] Erro durante updatePopupDisplay:", e);
        formatProfitPercentageForDisplay(NaN, popupProfitEEl);
        formatProfitPercentageForDisplay(NaN, popupProfitSEl);
        if (popupProfitEEl) popupProfitEEl.textContent = "Erro";
    }
}

window.onload = () => {
    const params = new URLSearchParams(window.location.search);
    pair = params.get('pair'); 
    originalDirection = params.get('direction'); 
    
    entryBuyExName = params.get('buyEx') || 'mexc'; 
    entrySellExName = params.get('sellEx') || 'mexc'; 

    if (originalDirection) {
        const dirParts = originalDirection.toLowerCase().split('/');
        if (dirParts.length === 2) {
            const buyLegFullDesc = dirParts[0].trim(); 
            entryBuyInstrumentIsSpot = buyLegFullDesc.includes("spot");
            const sellLegFullDesc = dirParts[1].trim(); 
            entrySellInstrumentIsSpot = sellLegFullDesc.includes("spot");
        }
    }

    updatePopupDisplay();
    window.profitUpdateInterval = setInterval(updatePopupDisplay, 1000);

    openChartButtonEl.addEventListener('click', () => {
        if (window.opener && window.opener.abrirGraficosComLayout) {
            window.opener.abrirGraficosComLayout(
                entryBuyExName, 
                entryBuyInstrumentIsSpot ? 'spot' : 'futures', 
                entrySellExName, 
                entrySellInstrumentIsSpot ? 'spot' : 'futures', 
                pair, 
                originalDirection, 
                '' 
            );
        } else {
            console.warn("FRONTEND: window.opener ou abrirGraficosComLayout não disponível.");
        }
    });

    window.addEventListener('beforeunload', () => {
        if (window.profitUpdateInterval) {
            clearInterval(window.profitUpdateInterval);
        }
    });
};

